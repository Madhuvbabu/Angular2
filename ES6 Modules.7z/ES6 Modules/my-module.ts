//module "my-module.js"

function cube(x){
return x*x*x;
}

const foo = Math.PI + mMath.SQRT2;
export {cube,foo};