"use strict";
exports.__esModule = true;
var my_module_1 = require("my-module");
console.log(my_module_1.cube(3));
console.log(my_module_1.foo);
