"use strict";
//module "my-module.js"
exports.__esModule = true;
function cube(x) {
    return x * x * x;
}
exports.cube = cube;
var foo = Math.PI + mMath.SQRT2;
exports.foo = foo;
