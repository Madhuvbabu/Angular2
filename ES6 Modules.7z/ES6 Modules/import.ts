import {cube, foo} from 'my-module';
console.log(cube(3));
console.log(foo);